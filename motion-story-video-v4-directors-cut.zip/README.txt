MOTION-STORY-VIDEO v4 — "DIRECTOR'S CUT" UPGRADE PACKAGE
=========================================================

CONTENTS
  motion-story-video-v4.skill ...... the upgraded skill (install like the original .skill file)
  sample_directors_cut_v4.mp4 ...... 18s sample film rendered with the v4 grammar + creative brief below
  creative_brief.json .............. the binding brief the Creative Director generated for the sample
                                     (topic: "why templates kill motion design", seed 25)

WHAT'S NEW IN v4 (vs the v1/v2 skill in this repo)
  1. CREATIVE DIRECTOR (fixes "every video looks the same")
     - scripts/creative_director.py: deterministic, topic-unique creative_brief.json with 9 BINDING
       direction axes: world metaphor, camera personality, palette mutation (non-purple hues only),
       texture kit, type attitude, pacing profile, signature motif, signature transition, lighting plan.
     - Novelty gate: --check ERRORS on any storyboard that reuses the example's cut skeleton, titles,
       accent #E4472C, or 27.0s shape. The v1/v2 demos shared the exact same cuts (3.67 / 7.47 /
       11.8 / 23.2s) because the example storyboard WAS the director. That can never happen again.
     - references/creative-director.md: the full direction doctrine.
  2. ENGINE v4 (assets/engine/)
     - Wide-angle lens: PERSP 1600 -> 900 (real parallax shear on every move).
     - Depth-scale compensation now OPT-IN (resting depth reads as depth).
     - Velocity-aware directional motion blur at 1x render cost (180-degree shutter follows |dCam/dt|).
     - Spotlight pool layer (look.pool), elevation shadows, glass HUD, halftone/scanline/torn-paper
       shaders, multiply ink — surgical anti-slop: purple SaaS gradients stay banned, cinema does not.
     - New components: zsandwich, clipping, inkloop, glasshud.
  3. CRAFT GATES (scripts/lint_v4_craft.py)
     - ERROR: hero text in space:"hud" · dead-hold gap > 1.15s · scene >= 3s with no real camera move
       · template reuse. WARN: <3 depth planes; missing creative_brief.json.

SAMPLE FILM NOTES
  Rendered deterministically in code (1280x720@30, temporal-supersampled motion blur on fast moves,
  layered foley audio: sub-drops, paper slaps, marker scrapes, typewriter). Archival imagery sampled
  from the push.mp4 benchmark for demonstration. Watch for: continuous macro->desk pullback, ink-loop
  + highlighter micro-beats, whip to the evidence wall with stamped exhibits, dolly-through into the
  dark brief world with glass HUD, and the typewriter payoff.
