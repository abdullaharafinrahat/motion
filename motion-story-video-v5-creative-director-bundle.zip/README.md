# Motion Story Video v5 — Creative Director Delivery

## Downloads

- `motion-story-video-v5.skill`: installable skill archive.
- `v5-output/creative-director-sample.mp4`: 21.5-second, 1280×720, 30 fps H.264/AAC sample.
- `creative-director-sample/`: editable direction record, treatment, history fingerprint, storyboard, and deterministic renderer.
- `motion-story-video-v5/`: unpacked skill source.

## What v5 changes

v5 addresses identical-looking outputs before storyboard generation. It requires exactly three formally different routes, scores them,
selects one with rationale, defines a content-specific motif and design system, blocks forbidden carryovers, and compares a concrete style
fingerprint against recent projects. The final gate verifies every scene refers to the selected direction and uses its motion verbs.

The camera is no longer a mandatory house signature. `direction.json` selects `shared_world`, `top_down`, `locked_observational`,
`footage_native`, `graphic_cuts`, `scene_based`, or `hybrid`, and the linter enforces only the selected mode.

## Sample

The sample selects **Field Temperature**, a cartographic/botanical field study about a moving shade route. It uses an asphalt/bone/coral/moss
palette, top-down tracking, contour drawing, botanical canopy rings, and trace/accumulate/redraw choreography. It intentionally avoids the
v4 sample's card wall, portrait cluster, orange world, monitor portal, italic-serif highlight, and velocity camera bank.

All visuals and audio are generated in code. No external footage, brands, photos, music, or quantitative climate claim are included.