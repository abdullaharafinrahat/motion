# Treatment: The Cool Route

## Story

- **Audience:** people who walk, plan, or care for hot city streets.
- **Goal:** make invisible differences in street heat and shade feel observable and navigable.
- **Promise:** a block changes when shade is read as a moving route rather than decoration.
- **Tension:** a street looks fixed while its usable climate moves through the day.
- **Emotional arc:** curiosity → exposure → recognition → agency.

## Three routes

### Route A: Field Temperature

A top-down field sheet treats the block as a measured specimen. Heat appears as coral contour density; canopy specimens accumulate as
moss circles; the contour motif redraws into a cooler walking route. This route translates every core noun and verb into one system and
can be executed honestly with code-native geometry. Risk: contour density can compete with type, so labels remain at the edges.

### Route B: Shade Witness

A locked documentary camera observes one corner over time while annotations record moving shadow and repeated pedestrian paths. It has a
strong emotional fit, but it requires rights-cleared time-separated footage from the same exact camera position, which is unavailable.

### Route C: Thermal Syntax

Full-frame type compresses under HEAT and opens under SHADE. The baseline becomes a route. It is distinct and feasible, but removing the
physical street/canopy relation weakens the clearest piece of explanation.

## Selected direction

**Field Temperature** wins for story fit, distinctiveness, and feasibility. The visual thesis is: *treat the street as a measured field
specimen whose contour lines become a cooler walking route when shade arrives.* The contour begins as heat measurement, becomes a boundary
interrupted by canopy, and pays off as the final route.

Composition stays top-down with annotations on the outer 18 percent and an empty asphalt field preserved in every beat. Large Archivo
statements are plain, never italic; IBM Plex Mono supplies small survey notes. Asphalt is ground, bone is drawing/text, coral is heat,
moss is shade/resolution, and dry yellow is measurement. Motion uses only **trace, accumulate, redraw**. Camera is a slow measured top-down
track, one macro push, and one still hold. Transitions are contour redraws with one hard thermal inversion. Sound uses graphite drag, dry
wood ticks, low outdoor air, and a deliberate silence before the final route.

Forbidden carryovers from v4 are card walls, portrait clusters, orange worlds, screen portals, serif-italic highlights, sticker bubbles,
and velocity banking.

## Six key frames

1. **Hook:** an almost empty asphalt field. One coral contour traces itself; the street grid is discovered beneath it.
2. **System:** bone block geometry and coordinate notes arrive while the line keeps tracing.
3. **Tension:** coral contours multiply tightly in unshaded areas; the frame hard-inverts for one beat.
4. **Turn:** moss canopy specimens accumulate, interrupt the coral fields, and cast soft measured shadows.
5. **Proof:** the camera holds while the same route crosses hot and shaded regions; labels identify what changed without numbers.
6. **Payoff:** all secondary lines fall away. The opening contour redraws as one moss route under “Walk the cool path.”

## Production

All visuals are coded geometry; no external image or trademark rights are involved. The sample makes no quantitative environmental claim.
Technical risk is line clutter at 720p, addressed by three line weights and strict label margins. The creative-history comparison finds the
v4 Beacon release film to be the nearest prior project, but this treatment changes world, composition, palette, imagery, motion, camera,
transition, sound, and motif. The final similarity remains low.