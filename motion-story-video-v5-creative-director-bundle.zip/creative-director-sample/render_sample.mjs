#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
import { spawn } from "node:child_process";
import { createCanvas, GlobalFonts } from "@napi-rs/canvas";

const require = createRequire(import.meta.url);
const ffmpeg = require("ffmpeg-static");
const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.resolve(here, "../v5-output");
const fontDir = path.resolve(here, "../motion-story-video-v5/assets/engine/fonts");
const W = 1280, H = 720, FPS = 30, DURATION = 21.5;
const SAMPLES = Number(process.env.MOTION_BLUR_SAMPLES || 2);
const C = {
  asphalt: "#1D2522", asphalt2: "#242D28", bone: "#E8E1D2", coral: "#D85B48",
  coralDark: "#913F35", moss: "#66845E", mossDark: "#425B42", yellow: "#C6AD55", mute: "#7A847C"
};

fs.mkdirSync(outDir, { recursive: true });
for (const [file, family] of [
  ["archivo-latin-500-normal.woff2", "Archivo"], ["archivo-latin-700-normal.woff2", "Archivo"],
  ["archivo-latin-800-normal.woff2", "Archivo"], ["ibm-plex-mono-latin-500-normal.woff2", "IBM Plex Mono"]
]) {
  const filePath = path.join(fontDir, file);
  if (fs.existsSync(filePath)) GlobalFonts.registerFromPath(filePath, family);
}

const canvas = createCanvas(W, H), ctx = canvas.getContext("2d");
const mix = createCanvas(W, H), mctx = mix.getContext("2d");
const clamp = (v, a=0, b=1) => Math.min(b, Math.max(a, v));
const lerp = (a,b,k) => a + (b-a)*k;
const prog = (t,a,d) => clamp((t-a)/d);
const smooth = (v) => v*v*(3-2*v);
const easeOut = (v) => 1-Math.pow(1-clamp(v),4);
const hash = (n) => { const x=Math.sin(n*127.1+311.7)*43758.5453; return x-Math.floor(x); };

const blocks = [
  [-470,-220,230,142],[-205,-220,205,142],[35,-220,250,142],[320,-220,185,142],
  [-470,-32,178,162],[-252,-32,262,162],[52,-32,198,162],[292,-32,213,162],
  [-470,174,248,154],[-178,174,190,154],[52,174,236,154],[330,174,175,154]
];
const trees = [
  [-330,-102,54],[-92,52,46],[172,-112,61],[372,84,48],[252,248,43],[-312,252,52],[25,250,39]
];
const hotSpots = [[-245,-112,1.0],[110,-130,.8],[335,15,.95],[-82,222,.72]];
const route = [[-508,278],[-395,197],[-272,144],[-160,54],[-44,82],[82,-6],[194,-74],[324,-38],[452,-155],[528,-214]];
const routeAltA = route.map(([x,y],i)=>[x,y + Math.sin(i*.9)*44 + 26]);
const routeAltB = route.map(([x,y],i)=>[x,y + Math.cos(i*.8)*36 - 18]);

function cameraAt(t) {
  if (t < 3.3) return {x:lerp(-70,-22,smooth(prog(t,0,3.3))), y:lerp(-30,-12,smooth(prog(t,0,3.3))), z:lerp(1,1.045,smooth(prog(t,0,3.3)))};
  if (t < 6.75) return {x:lerp(-22,72,smooth(prog(t,3.3,3.45))), y:lerp(-12,-25,smooth(prog(t,3.3,3.45))), z:lerp(1.045,1.18,smooth(prog(t,3.3,3.45)))};
  if (t < 10.25) return {x:lerp(72,108,smooth(prog(t,6.75,3.5))), y:lerp(-25,14,smooth(prog(t,6.75,3.5))), z:lerp(1.18,1.11,smooth(prog(t,6.75,3.5)))};
  if (t < 14.25) return {x:108,y:14,z:1.0};
  if (t < 17.45) return {x:lerp(108,126,smooth(prog(t,14.25,3.2))), y:lerp(14,3,smooth(prog(t,14.25,3.2))), z:lerp(1.07,1.1,smooth(prog(t,14.25,3.2)))};
  return {x:lerp(126,142,smooth(prog(t,17.45,4.05))), y:lerp(3,-4,smooth(prog(t,17.45,4.05))), z:lerp(1.1,1.13,smooth(prog(t,17.45,4.05)))};
}

function mapTransform(t, fn) {
  const cam = cameraAt(t);
  ctx.save(); ctx.translate(W*.58,H*.52); ctx.scale(cam.z,cam.z); ctx.translate(-cam.x,-cam.y); fn(); ctx.restore();
}

function background(t) {
  ctx.fillStyle = C.asphalt; ctx.fillRect(0,0,W,H);
  // Dry field-sheet texture, deterministic per frame but visually stable.
  ctx.save(); ctx.globalAlpha=.055;
  for (let i=0;i<680;i++) {
    const x=hash(i*3.13)*W, y=hash(i*7.91)*H, r=.3+hash(i*11.7)*1.1;
    ctx.fillStyle = i%4===0 ? C.bone : "#000"; ctx.fillRect(x,y,r,r);
  }
  ctx.restore();
  const edge=ctx.createRadialGradient(W*.56,H*.52,120,W*.56,H*.52,780);
  edge.addColorStop(0,"rgba(0,0,0,0)"); edge.addColorStop(1,"rgba(0,0,0,.3)");
  ctx.fillStyle=edge; ctx.fillRect(0,0,W,H);
  // Single hard thermal inversion, not a reusable transition preset.
  const inv=1-Math.abs(clamp((t-6.62)/.16)*2-1);
  if (inv>0) { ctx.globalAlpha=inv*.9; ctx.fillStyle=C.bone; ctx.fillRect(0,0,W,H); ctx.globalAlpha=1; }
}

function mono(text,x,y,size=13,color=C.yellow,align="left") {
  ctx.save(); ctx.font=`500 ${size}px 'IBM Plex Mono'`; ctx.textAlign=align; ctx.textBaseline="alphabetic";
  ctx.fillStyle=color; ctx.fillText(text,x,y); ctx.restore();
}
function display(lines,x,y,size=66,color=C.bone,alpha=1) {
  ctx.save(); ctx.globalAlpha=alpha; ctx.font=`700 ${size}px Archivo`; ctx.textAlign="left"; ctx.textBaseline="top"; ctx.fillStyle=color;
  lines.forEach((line,i)=>ctx.fillText(line,x,y+i*size*.93)); ctx.restore();
}
function leader(x1,y1,x2,y2,label,align="left") {
  ctx.save(); ctx.strokeStyle="rgba(232,225,210,.52)"; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y1); ctx.lineTo(x2,y2); ctx.stroke();
  mono(label,x2+(align==="left"?8:-8),y2+4,11,C.bone,align); ctx.fillStyle=C.yellow; ctx.beginPath(); ctx.arc(x1,y1,3,0,Math.PI*2); ctx.fill(); ctx.restore();
}

function drawStreetBase(alpha=1) {
  ctx.save(); ctx.globalAlpha=alpha;
  // Survey coordinates.
  ctx.strokeStyle="rgba(232,225,210,.075)"; ctx.lineWidth=1;
  for(let x=-560;x<=560;x+=80){ctx.beginPath();ctx.moveTo(x,-350);ctx.lineTo(x,350);ctx.stroke();}
  for(let y=-350;y<=350;y+=80){ctx.beginPath();ctx.moveTo(-560,y);ctx.lineTo(560,y);ctx.stroke();}
  // Blocks remain unfilled so asphalt is the material.
  blocks.forEach(([x,y,w,h],i)=>{
    ctx.strokeStyle=i%3===0?"rgba(232,225,210,.44)":"rgba(232,225,210,.27)"; ctx.lineWidth=i%3===0?2:1;
    ctx.strokeRect(x,y,w,h);
    if(i%3===0){ctx.fillStyle="rgba(232,225,210,.035)";ctx.fillRect(x,y,w,h);}
    ctx.save(); ctx.translate(x+10,y+19); ctx.font="500 10px 'IBM Plex Mono'";ctx.fillStyle="rgba(232,225,210,.42)";ctx.fillText(`B${String(i+1).padStart(2,"0")}`,0,0);ctx.restore();
  });
  // Crossings.
  ctx.strokeStyle="rgba(198,173,85,.38)";ctx.lineWidth=2;
  [-275,20,285].forEach(x=>{for(let i=0;i<7;i++){ctx.beginPath();ctx.moveTo(x+i*9,-62);ctx.lineTo(x+i*9,-40);ctx.stroke();}});
  ctx.restore();
}

function polyline(points,color,width,progress=1,dash=[]) {
  if(progress<=0)return;
  const seg=[]; let total=0;
  for(let i=1;i<points.length;i++){const d=Math.hypot(points[i][0]-points[i-1][0],points[i][1]-points[i-1][1]);seg.push(d);total+=d;}
  let remain=total*clamp(progress);
  ctx.save();ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap="round";ctx.lineJoin="round";ctx.setLineDash(dash);ctx.beginPath();ctx.moveTo(...points[0]);
  for(let i=1;i<points.length&&remain>0;i++){
    if(remain>=seg[i-1]){ctx.lineTo(...points[i]);remain-=seg[i-1];}
    else {const k=remain/seg[i-1];ctx.lineTo(lerp(points[i-1][0],points[i][0],k),lerp(points[i-1][1],points[i][1],k));remain=0;}
  }
  ctx.stroke();ctx.restore();
}

function contour(cx,cy,rx,ry,phase,color,width,progress=1,alpha=1) {
  const pts=[];for(let i=0;i<=90;i++){const a=i/90*Math.PI*2;const wob=1+Math.sin(a*3+phase)*.085+Math.cos(a*5-phase)*.045;pts.push([cx+Math.cos(a)*rx*wob,cy+Math.sin(a)*ry*wob]);}
  ctx.save();ctx.globalAlpha=alpha;polyline(pts,color,width,progress);ctx.restore();
}
function heatField(t,intensity=1) {
  hotSpots.forEach(([x,y,p],hi)=>{
    for(let ring=0;ring<5;ring++){
      const start=3.35+hi*.17+ring*.12;const progress=easeOut(prog(t,start,1.1));
      contour(x,y,48+ring*24,34+ring*17,hi+ring*.6,C.coral,ring===0?3:1.5,progress,intensity*(.92-ring*.12)*p);
    }
    // Hatching makes heat feel printed, not glowing.
    ctx.save();ctx.globalAlpha=.16*intensity*p;ctx.strokeStyle=C.coral;ctx.lineWidth=1;
    for(let k=-45;k<55;k+=10){ctx.beginPath();ctx.moveTo(x-50,y+k);ctx.lineTo(x+55,y+k-35);ctx.stroke();}ctx.restore();
  });
}
function canopy(x,y,r,t,start) {
  const p=easeOut(prog(t,start,.7)); if(p<=0)return;
  ctx.save();ctx.globalAlpha=.16*p;ctx.fillStyle="#0C110E";ctx.beginPath();ctx.arc(x+18,y+24,r*1.08*p,0,Math.PI*2);ctx.fill();ctx.restore();
  ctx.save();ctx.scale(p,p);ctx.translate(x/p,y/p); // scale from local center
  ctx.fillStyle="rgba(102,132,94,.16)";ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle=C.moss;ctx.lineWidth=3;ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.stroke();
  ctx.lineWidth=1;ctx.globalAlpha=.72;for(let q=1;q<=3;q++){ctx.beginPath();ctx.arc(0,0,r*q/4,0,Math.PI*2);ctx.stroke();}
  ctx.beginPath();ctx.moveTo(-r,0);ctx.lineTo(r,0);ctx.moveTo(0,-r);ctx.lineTo(0,r);ctx.stroke();ctx.restore();
}
function drawTrees(t,alpha=1) {ctx.save();ctx.globalAlpha=alpha;trees.forEach(([x,y,r],i)=>canopy(x,y,r,t,6.8+i*.27));ctx.restore();}

function cornerSystem(index,label,subtitle) {
  mono(`FIELD NOTE ${String(index).padStart(2,"0")}`,54,48,12,C.yellow);
  ctx.strokeStyle="rgba(198,173,85,.5)";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(54,61);ctx.lineTo(194,61);ctx.stroke();
  mono(label.toUpperCase(),54,H-48,11,C.bone);mono(subtitle.toUpperCase(),W-54,H-48,11,C.mute,"right");
}

function hook(t) {
  const p=easeOut(prog(t,.15,2.55));
  mapTransform(t,()=>{drawStreetBase(lerp(.12,1,p));contour(-58,-12,285,178,.4,C.coral,7,p,1);contour(-58,-12,325,207,1.1,C.mute,2,prog(t,.65,2.1),.65);});
  display(["A block has","a climate."],54,92,69,C.bone,easeOut(prog(t,.25,.75)));
  cornerSystem(1,"Top-down survey","No quantitative claim");
  if(t>1.5)leader(830,230,1072,116,"HEAT CONTOUR");
}
function tension(t) {
  mapTransform(t,()=>{drawStreetBase(1);heatField(t,1);});
  display(["Heat collects","where shade ends."],54,92,60,C.bone,easeOut(prog(t,3.3,.6)));
  cornerSystem(2,"Exposed field","Coral = heat concentration");
  if(t>4.8){leader(920,485,1090,576,"UNSHADED GAP");mono("DENSITY, NOT DECORATION",54,275,11,C.coral);}
}
function turn(t) {
  mapTransform(t,()=>{drawStreetBase(1);heatField(t,.46);drawTrees(t,1);polyline(routeAltA,C.mute,2,prog(t,8.5,1.2),[8,10]);});
  display(["But shade","moves."],54,92,72,C.bone,easeOut(prog(t,6.8,.55)));
  cornerSystem(3,"Canopy pass","Moss = shade / relief");
  if(t>8.15){leader(775,274,1062,154,"CANOPY SPECIMEN");leader(960,465,1090,565,"CAST SHADOW");}
}
function timePasses(t) {
  // Three horizontal survey strips, not interface cards.
  display(["Read the block","over time."],54,80,55,C.bone,easeOut(prog(t,10.25,.55)));
  cornerSystem(4,"Three passes","Same block / moving shade");
  const labels=["09:00","13:00","17:00"], paths=[routeAltA,route,routeAltB], cols=[C.coral,C.yellow,C.moss];
  for(let band=0;band<3;band++){
    const y=215+band*140;mono(labels[band],54,y+6,12,cols[band]);
    ctx.strokeStyle="rgba(232,225,210,.2)";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(150,y);ctx.lineTo(W-65,y);ctx.stroke();
    ctx.save();ctx.translate(285,y-70);ctx.scale(.72,.23);drawStreetBase(.28);polyline(paths[band],cols[band],14,easeOut(prog(t,10.55+band*.38,1.15)));ctx.restore();
  }
  if(t>12.6)mono("THE ROUTE CHANGES BECAUSE THE FIELD CHANGES",682,654,11,C.bone,"center");
}
function proof(t) {
  mapTransform(t,()=>{drawStreetBase(.72);heatField(t,.23);drawTrees(20,1);polyline(route,C.moss,15,easeOut(prog(t,14.45,2.2)));polyline(route.slice(0,4),C.coral,4,easeOut(prog(t,14.45,.9)));});
  display(["The cooler path","is already there."],54,92,58,C.bone,easeOut(prog(t,14.25,.55)));
  cornerSystem(5,"Route study","Compare conditions, not claims");
  if(t>15.55){leader(708,506,1052,588,"EXPOSED SEGMENT");leader(938,306,1080,174,"SHADED SEGMENT");}
}
function payoff(t) {
  const fade=1-smooth(prog(t,17.4,1.0));
  mapTransform(t,()=>{drawStreetBase(.18*fade);drawTrees(20,.22*fade);polyline(route,C.moss,17,easeOut(prog(t,17.65,2.75)));});
  display(["Walk the","cool path."],54,112,78,C.bone,easeOut(prog(t,17.65,.65)));
  cornerSystem(6,"Contour → route","Shade is part of the path");
  if(t>20.15){ctx.strokeStyle=C.yellow;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(54,608);ctx.lineTo(344,608);ctx.stroke();mono("THE OPENING MEASUREMENT BECOMES THE ROUTE",54,636,11,C.bone);}
}

function render(t) {
  background(t);
  if(t<3.3)hook(t);else if(t<6.75)tension(t);else if(t<10.25)turn(t);else if(t<14.25)timePasses(t);else if(t<17.45)proof(t);else payoff(t);
  // Tiny registration marks reinforce field-sheet material without becoming a UI overlay.
  ctx.save();ctx.strokeStyle="rgba(232,225,210,.25)";ctx.lineWidth=1;
  [[22,22],[W-22,22],[22,H-22],[W-22,H-22]].forEach(([x,y])=>{ctx.beginPath();ctx.moveTo(x-7,y);ctx.lineTo(x+7,y);ctx.moveTo(x,y-7);ctx.lineTo(x,y+7);ctx.stroke();});ctx.restore();
}

function synthAudio(file) {
  const rate=48000, frames=Math.floor(rate*DURATION), pcm=Buffer.alloc(frames*4);
  const ticks=[.2,1.6,3.25,4.75,6.68,7.45,8.25,10.24,11.05,11.75,12.45,14.24,15.45,17.42,20.2];
  for(let i=0;i<frames;i++){
    const t=i/rate; let v=0;
    // Low field air and restrained tonal bed.
    const noise=(hash(i*.071)-.5)*2;
    v += noise*.018 + Math.sin(Math.PI*2*55*t)*.028 + Math.sin(Math.PI*2*82.5*t)*.015;
    // Graphite drag while lines are actively tracing.
    const tracing = (t<2.8)||(t>3.5&&t<6.3)||(t>8.3&&t<9.8)||(t>10.5&&t<13.6)||(t>14.4&&t<16.9)||(t>17.65&&t<20.45);
    if(tracing) v += (hash(i*.43)-.5)*.052*(.35+.65*Math.sin(t*17)**2);
    // Dry wooden measurement ticks.
    for(const hit of ticks){const d=t-hit;if(d>=0&&d<.16){const e=Math.exp(-d*28);v+=Math.sin(2*Math.PI*(480-d*900)*d)*e*.17;}}
    // Planned silence before final redraw.
    if(t>16.9&&t<17.5)v*=.05;
    const fade=Math.min(1,t/.25,(DURATION-t)/.45);v=Math.tanh(v*1.25)*Math.max(0,fade)*.78;
    const vr=Math.tanh((v + noise*.004)*1.02);
    pcm.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(v*32767))),i*4);
    pcm.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(vr*32767))),i*4+2);
  }
  const h=Buffer.alloc(44);h.write("RIFF",0);h.writeUInt32LE(36+pcm.length,4);h.write("WAVE",8);h.write("fmt ",12);h.writeUInt32LE(16,16);h.writeUInt16LE(1,20);h.writeUInt16LE(2,22);h.writeUInt32LE(rate,24);h.writeUInt32LE(rate*4,28);h.writeUInt16LE(4,32);h.writeUInt16LE(16,34);h.write("data",36);h.writeUInt32LE(pcm.length,40);fs.writeFileSync(file,Buffer.concat([h,pcm]));
}

async function write(stream,buf){if(stream.write(buf))return;await new Promise((res,rej)=>{stream.once("drain",res);stream.once("error",rej);});}
async function main(){
  const wav=path.join(outDir,"field-score.wav"), out=path.join(outDir,"creative-director-sample.mp4");synthAudio(wav);
  const ff=spawn(ffmpeg,["-hide_banner","-loglevel","error","-y","-f","image2pipe","-framerate",String(FPS),"-vcodec","mjpeg","-i","pipe:0","-i",wav,"-t",String(DURATION),"-map","0:v:0","-map","1:a:0","-c:v","libx264","-preset","medium","-crf","18","-pix_fmt","yuv420p","-r",String(FPS),"-c:a","aac","-b:a","160k","-movflags","+faststart",out],{stdio:["pipe","ignore","inherit"]});
  const total=Math.round(DURATION*FPS);
  for(let f=0;f<total;f++){
    mctx.setTransform(1,0,0,1,0,0);mctx.globalAlpha=1;mctx.fillStyle=C.asphalt;mctx.fillRect(0,0,W,H);
    for(let s=0;s<SAMPLES;s++){const sub=(s+.5)/SAMPLES-.5;render(clamp((f+sub*.38)/FPS,0,DURATION));mctx.globalAlpha=1/SAMPLES;mctx.drawImage(canvas,0,0);}
    mctx.globalAlpha=1;await write(ff.stdin,mix.toBuffer("image/jpeg",90));if(f%90===0)console.log(`Rendered ${f}/${total} (${(f/FPS).toFixed(1)}s)`);
  }
  ff.stdin.end();await new Promise((res,rej)=>ff.once("close",code=>code===0?res():rej(new Error(`ffmpeg exited ${code}`))));fs.unlinkSync(wav);console.log(`Wrote ${out}`);
}
main().catch(e=>{console.error(e);process.exitCode=1;});