# The Cool Route — Creative Director v5 sample

This 21.5-second sample demonstrates the v5 direction gate. It is deliberately unlike the v4 orange collage/portal sample.

- **Selected concept:** Field Temperature
- **Visual thesis:** a street is treated as a measured specimen whose heat contours become a cooler walking route when shade arrives.
- **Motif:** contour line → interrupted boundary → walking route.
- **Motion verbs:** trace, accumulate, redraw.
- **Camera mode:** top-down measured track with a proof hold; no portal, orbit, card wall, or velocity bank.
- **Material:** asphalt field sheet, dry ink, botanical cross-sections.
- **Sound:** generated graphite drag, dry wood ticks, field air, and a planned silence.

Files:

- `direction.json`: three routes, scores, selected system, fingerprint, similarity review.
- `creative-history.json`: previous v4 fingerprint used to detect repetition.
- `TREATMENT.md`: human-readable Creative Director decision record.
- `storyboard.json`: scenes tied to direction ID, purpose, and selected motion verbs.
- `render_sample.mjs`: deterministic Canvas/FFmpeg renderer with an original generated stereo score.

Render from the repository root:

```bash
npm install --no-save @napi-rs/canvas ffmpeg-static
node deliverables/creative-director-sample/render_sample.mjs
```

The output is `deliverables/v5-output/creative-director-sample.mp4` (1280×720, 30 fps, H.264/AAC). It makes no quantitative climate
claim and uses no third-party footage, logos, music, or photography.