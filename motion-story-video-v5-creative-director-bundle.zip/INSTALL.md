# Install motion-story-video v5

1. Download `motion-story-video-v5.skill`.
2. Open the skill manager/import screen in the AI client or agent runtime where you use skills.
3. Choose **Import/Add skill** and select the downloaded `.skill` file.

The website can download the file, but a browser cannot install a local skill automatically. If your runtime accepts an unpacked skill
folder instead of `.skill` archives, unzip the file and import the canonical `motion-story-video/` folder containing `SKILL.md`.

The `.skill` file is intentionally a ZIP-format archive with this installer-compatible structure:

```text
motion-story-video/
  SKILL.md
  README.md
  assets/
  references/
  scripts/
```

If a browser changes the downloaded filename to `.zip`, rename it back to `motion-story-video-v5.skill` before importing, or unzip it and
import the `motion-story-video` folder if your runtime supports folder installation.